<template>
    <AppLayout>
        <Head title="My Routines" />

        <div class="routines-page">
            <div class="routines-container">
                <div class="routines-content">
                    <div class="routines-header">
                        <h1>Manas rutīnas</h1>
                        <div class="header-actions">
                            <Link v-if="isAuthenticated" href="/routines/create" class="create-button">
                            Izveidot jaunu rutīnu
                            </Link>
                            <div v-else class="auth-required-message">
                                Pierakstieties, lai izveidotu rutīnas
                            </div>
                        </div>
                    </div>

                    <!-- Aktīvās rutīnas indikators -->
                    <div v-if="isAuthenticated && activeRoutine" class="active-routine-banner">
                        <div class="active-routine-content">
                            <div class="routine-info">
                                <h3>🏋️ Aktīvā rutīna</h3>
                                <h4>{{ activeRoutine.name }}</h4>
                                <div class="routine-details">
                                    <span class="exercise-count">{{ getTotalExercisesCount(activeRoutine) }} vingrinājumi</span>
                                    <span v-if="activeRoutine.is_public" class="public-tag">Publiska</span>
                                </div>
                            </div>
                            <button @click="clearActiveRoutine" class="remove-active-btn">
                                Noņemt
                            </button>
                        </div>
                    </div>

                    <div class="routines-list">
                        <div class="routines-grid">
                            <div v-for="routine in routines" :key="routine.id"
                                 :class="['routine-card', routine.id === activeRoutine?.id ? 'active-routine' : '']">
                                <div class="routine-content">
                                    <div class="routine-header">
                                        <h2>{{ routine.name }}</h2>
                                        <div v-if="isAuthenticated && routine.id === activeRoutine?.id" class="active-badge">
                                            Aktīvā
                                        </div>
                                    </div>
                                    <p class="routine-description">{{ routine.description || 'Nav apraksta' }}</p>

                                    <div class="routine-meta">
                                        <span class="exercise-count">{{ getTotalExercisesCount(routine) }} vingrinājumi</span>
                                        <span v-if="routine.is_public" class="public-tag">Publiska</span>
                                    </div>

                                    <div class="routine-actions">
                                        <button @click="viewRoutineDetails(routine)" class="view-btn">
                                            👁️ Skatīt
                                        </button>

                                        <button v-if="isAuthenticated" @click="editRoutine(routine)" class="edit-btn">
                                            ✏️ Rediģēt
                                        </button>

                                        <button v-if="isAuthenticated" @click="startRoutineWorkout(routine)" class="start-btn">
                                            ▶️ Sākt treniņu
                                        </button>
                                        <button v-if="isAuthenticated"
                                                @click="setAsActiveRoutine(routine)"
                                                :class="['set-active-btn', routine.id === activeRoutine?.id ? 'is-active' : '']">
                                            {{ routine.id === activeRoutine?.id ? '✅ Aktīvā' : '⭐ Iestatīt' }}
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div v-if="routines.length === 0" class="empty-state">
                                <div class="empty-icon">
                                    🏋️
                                </div>
                                <p>Jums vēl nav izveidota neviena rutīna.</p>
                                <Link v-if="isAuthenticated" href="/routines/create" class="create-button">
                                Izveidot pirmo rutīnu
                                </Link>
                                <div v-else class="auth-message">
                                    <p>Pierakstieties, lai izveidotu rutīnas!</p>
                                    <Link href="/login" class="login-btn">
                                    Pierakstīties
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rutīnas detaļu modals -->
            <div v-if="selectedRoutine" class="modal-overlay" @click.self="closeModal">
                <div class="modal">
                    <div class="modal-header">
                        <h2>{{ selectedRoutine.name }}</h2>
                        <button @click="closeModal" class="modal-close">
                            ✕
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="modal-section">
                            <h3>📝 Apraksts</h3>
                            <p>{{ selectedRoutine.description || 'Nav apraksta' }}</p>
                        </div>

                        <div class="modal-section">
                            <h3>📊 Informācija</h3>
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">Vingrinājumi:</span>
                                    <span class="info-value">{{ getTotalExercisesCount(selectedRoutine) }}</span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Statuss:</span>
                                    <span :class="['info-value', selectedRoutine.is_public ? 'public' : 'private']">
                                        {{ selectedRoutine.is_public ? 'Publiska' : 'Privāta' }}
                                    </span>
                                </div>
                                <div v-if="isAuthenticated && selectedRoutine.id === activeRoutine?.id" class="info-item">
                                    <span class="info-label">Status:</span>
                                    <span class="info-value active">⭐ Aktīvā</span>
                                </div>
                            </div>
                        </div>

                        <div class="modal-section">
                            <h3>🗓️ Nedēļas grafiks</h3>
                            <div class="week-schedule-detailed">
                                <div v-for="day in 7" :key="day" class="day-plan">
                                    <div class="day-header">
                                        <h4>{{ getDayName(day) }}</h4>
                                        <span class="day-count">
                                            {{ getExercisesCountForDay(selectedRoutine, day) }} vingrinājumi
                                        </span>
                                    </div>

                                    <div v-if="getExercisesForDay(selectedRoutine, day).length > 0" class="exercises-list">
                                        <div v-for="exercise in getExercisesForDay(selectedRoutine, day)"
                                             :key="exercise.id || exercise.name"
                                             class="exercise-card">
                                            <div class="exercise-header">
                                                <div class="exercise-title">
                                                    <h5>{{ exercise.name }}</h5>
                                                    <span class="muscle-badge">{{ exercise.muscle_group }}</span>
                                                </div>
                                            </div>

                                            <div class="exercise-specs">
                                                <div class="spec-item">
                                                    <span class="spec-label">Seti:</span>
                                                    <span class="spec-value">{{ exercise.sets || exercise.pivot?.sets || 3 }}</span>
                                                </div>
                                                <div class="spec-item">
                                                    <span class="spec-label">Reps:</span>
                                                    <span class="spec-value">{{ exercise.reps || exercise.pivot?.reps || 10 }}</span>
                                                </div>
                                                <div v-if="exercise.weight || (exercise.pivot && exercise.pivot.weight)" class="spec-item">
                                                    <span class="spec-label">Svars:</span>
                                                    <span class="spec-value">{{ exercise.weight || (exercise.pivot && exercise.pivot.weight) }}kg</span>
                                                </div>

                                                <div v-if="exercise.rest_time || (exercise.pivot && exercise.pivot.rest_time)" class="spec-item">
                                                    <span class="spec-label">Atpūta:</span>
                                                    <span class="spec-value">{{ exercise.rest_time || (exercise.pivot && exercise.pivot.rest_time) }}s</span>
                                                </div>
                                            </div>

                                            <div v-if="exercise.notes || exercise.pivot?.notes" class="exercise-notes">
                                                <span class="notes-label">Piezīmes:</span>
                                                <p>{{ exercise.notes || exercise.pivot?.notes }}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div v-else class="rest-day">
                                        🛌 Atpūtas diena
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button v-if="isAuthenticated" @click="startRoutineWorkout(selectedRoutine)" class="btn btn-primary">
                            ▶️ Sākt treniņu
                        </button>

                        <button v-if="isAuthenticated" @click="editRoutine(selectedRoutine)" class="btn btn-warning">
                            ✏️ Rediģēt
                        </button>

                        <button v-if="isAuthenticated"
                                @click="setAsActiveRoutine(selectedRoutine)"
                                :class="['btn', selectedRoutine.id === activeRoutine?.id ? 'btn-success' : 'btn-secondary']">
                            {{ selectedRoutine.id === activeRoutine?.id ? '✅ Aktīvā' : '⭐ Iestatīt kā aktīvo' }}
                        </button>
                        <button @click="closeModal" class="btn btn-outline">
                            Aizvērt
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </AppLayout>
</template>

<script setup>
    import AppLayout from '@/Layouts/AppLayout.vue';
    import { Head, Link, router } from '@inertiajs/vue3';
    import { ref, onMounted, onUnmounted, computed } from 'vue';
    import axios from 'axios';

    const props = defineProps({
        routines: Array,
        auth: Object,
    });

    const activeRoutine = ref(null);
    const selectedRoutine = ref(null);

    const isAuthenticated = computed(() => {
        return props.auth && props.auth.user;
    });

    const dayNames = {
        1: 'Pirmdiena',
        2: 'Otrdiena',
        3: 'Trešdiena',
        4: 'Ceturtdiena',
        5: 'Piektdiena',
        6: 'Sestdiena',
        7: 'Svētdiena'
    };

    // Palīgfunkcijas
    const getDayName = (dayNumber) => {
        return dayNames[dayNumber] || `Diena ${dayNumber}`;
    };

    const getExercisesCountForDay = (routine, dayNumber) => {
        if (!routine.exercises) return 0;

        return routine.exercises.filter(exercise => {
            return exercise.pivot?.day_number === dayNumber;
        }).length;
    };

    const getExercisesForDay = (routine, dayNumber) => {
        if (!routine.exercises) return [];

        return routine.exercises.filter(exercise => {
            return exercise.pivot?.day_number === dayNumber;
        });
    };

    const getTotalExercisesCount = (routine) => {
        if (!routine.exercises) return 0;

        // Grupē pēc dienām un saskaita unikālos vingrinājumus
        const uniqueExerciseIds = new Set();
        routine.exercises.forEach(exercise => {
            uniqueExerciseIds.add(exercise.id);
        });

        return uniqueExerciseIds.size;
    };

    const editRoutine = (routine) => {
        if (!isAuthenticated.value) {
            alert('Lūdzu, pierakstieties, lai rediģētu rutīnas!');
            return;
        }

        console.log('Editing routine:', routine.id);

        // Aizveram modālu, ja tas ir atvērts
        if (selectedRoutine.value?.id === routine.id) {
            closeModal();
        }

        // Pārejam uz rediģēšanas lapu
        router.visit(`/routines/${routine.id}/edit`);
    };

    onMounted(() => {
        if (isAuthenticated.value) {
            const saved = localStorage.getItem('activeRoutine');
            if (saved) {
                try {
                    activeRoutine.value = JSON.parse(saved);
                } catch (e) {
                    console.error('Error parsing active routine:', e);
                    localStorage.removeItem('activeRoutine');
                }
            }
        }

        document.addEventListener('keydown', handleEscape);
    });

    onUnmounted(() => {
        document.removeEventListener('keydown', handleEscape);
    });

    const setAsActiveRoutine = async (routine) => {
        if (!isAuthenticated.value) {
            alert('Lūdzu, pierakstieties, lai iestatītu aktīvo rutīnu!');
            return;
        }

        try {
            console.log('Setting active routine:', routine.id, routine.name);

            // 1. Mēģinām saglabāt serverī
            const response = await axios.post(`/routines/${routine.id}/set-active`);
            console.log('Server response:', response.data);

            // 2. Iegūstam pilnus rutīnas datus
            let routineData;
            if (response.data && response.data.routine) {
                // Izmantojam servera atbildi
                routineData = response.data.routine;
            } else {
                // Ja serveris neatgriež datus, izmantojam lokālos
                routineData = {
                    id: routine.id,
                    name: routine.name,
                    description: routine.description || '',
                    is_public: routine.is_public || false,
                    exercises_count: routine.exercises?.length || 0,
                    exercises: (routine.exercises || []).map(ex => ({
                        id: ex.id,
                        name: ex.name,
                        muscle_group: ex.muscle_group || '',
                        sets: (ex.pivot && ex.pivot.sets) || 3,
                        reps: (ex.pivot && ex.pivot.reps) || 10,
                        rest_seconds: (ex.pivot && ex.pivot.rest_seconds) || 60,
                        day_number: (ex.pivot && ex.pivot.day_number) || 1,
                        notes: (ex.pivot && ex.pivot.notes) || ''
                    }))
                };
            }

            console.log('Saving to localStorage:', routineData);
            localStorage.setItem('activeRoutine', JSON.stringify(routineData));
            activeRoutine.value = routineData;

            // 3. Paziņojam par izmaiņām
            localStorage.setItem('routineChanged', 'true');

            // 4. Parādām veiksmes ziņojumu
            alert(`✅ Rutīna "${routine.name}" iestatīta kā aktīvā!`);

            // 5. Aizveram modālu, ja atvērts
            if (selectedRoutine.value?.id === routine.id) {
                closeModal();
            }

        } catch (error) {
            console.error('Full error details:', error);
            // ... error handling ...
        }
    };

    const clearActiveRoutine = () => {
        if (!isAuthenticated.value) return;

        localStorage.removeItem('activeRoutine');
        activeRoutine.value = null;
        localStorage.setItem('routineChanged', 'true');
    };

    const viewRoutineDetails = (routine) => {
        selectedRoutine.value = routine;
        document.body.style.overflow = 'hidden';
    };

    const closeModal = () => {
        selectedRoutine.value = null;
        document.body.style.overflow = 'auto';
    };

    const startRoutineWorkout = async (routine) => {
        if (!isAuthenticated.value) {
            alert('Lūdzu, pierakstieties, lai sāktu treniņu!');
            return;
        }

        try {
            // 1. Nosakām šodienas dienas numuru
            const today = new Date();
            const dayNumber = today.getDay(); // 0-6
            let todayDayNumber = dayNumber === 0 ? 7 : dayNumber;

            // 2. Filtrējam vingrinājumus šodienai
            const exercisesForToday = (routine.exercises || [])
                .filter(exercise => {
                    const exerciseDay = exercise.pivot?.day_number || exercise.day_number || 1;
                    return exerciseDay === todayDayNumber;
                })
                .map(exercise => ({
                    id: exercise.id,
                    name: exercise.name,
                    muscle_group: exercise.muscle_group || '',
                    sets: exercise.pivot?.sets || exercise.sets || 3,
                    reps: exercise.pivot?.reps || exercise.reps || 10,
                    rest_seconds: exercise.pivot?.rest_seconds || exercise.rest_seconds || 60,
                    notes: exercise.pivot?.notes || exercise.notes || '',
                    day_number: exercise.pivot?.day_number || exercise.day_number || 1
                }));

            console.log('Starting routine workout:', {
                routineId: routine.id,
                routineName: routine.name,
                todayDayNumber: todayDayNumber,
                exercisesCount: exercisesForToday.length
            });

            if (exercisesForToday.length === 0) {
                const dayNames = ['Svētdiena', 'Pirmdiena', 'Otrdiena', 'Trešdiena', 'Ceturtdiena', 'Piektdiena', 'Sestdiena'];
                alert(`Šodien (${dayNames[todayDayNumber]}) nav vingrinājumu rutīnā "${routine.name}".`);
                return;
            }

            // 3. Izveidojam brīvo treniņu
            const response = await axios.post('/workout/free/start', {
                name: routine.name + ' - ' + new Date().toLocaleDateString('lv-LV'),
                routine_id: routine.id,
                exercises: exercisesForToday
            });

            if (response.data && response.data.success) {
                if (response.data.session_id) {
                    router.visit(`/workout/free?session=${response.data.session_id}`);
                } else {
                    router.visit('/workout/free');
                }
            } else {
                throw new Error(response.data?.message || 'Unknown error');
            }

        } catch (error) {
            console.error('Error starting routine workout:', error);

            let errorMessage = 'Kļūda sākot treniņu: ';
            if (error.response?.data?.message) {
                errorMessage += error.response.data.message;
            } else if (error.message) {
                errorMessage += error.message;
            }

            alert(errorMessage);
        }
    };

    const handleEscape = (e) => {
        if (e.key === 'Escape' && selectedRoutine.value) {
            closeModal();
        }
    };
</script>

<style scoped>
    .week-schedule {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 0.25rem;
        margin-bottom: 1rem;
        background: #f8fafc;
        border-radius: 0.5rem;
        padding: 0.5rem;
        border: 1px solid #e2e8f0;
    }

    .day-summary {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 0.25rem;
        border-radius: 0.375rem;
        background: white;
        font-size: 0.75rem;
    }

    .day-name {
        color: #64748b;
        font-weight: 500;
        margin-bottom: 0.125rem;
    }

    .day-exercises {
        background: #3b82f6;
        color: white;
        width: 1.5rem;
        height: 1.5rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 0.625rem;
    }

    .week-schedule-detailed {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .day-plan {
        background: #f8fafc;
        border-radius: 0.75rem;
        padding: 1.25rem;
        border: 1px solid #e2e8f0;
    }

    .day-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
        padding-bottom: 0.75rem;
        border-bottom: 1px solid #e2e8f0;
    }

    .edit-btn {
        background: #f59e0b;
        color: white;
        flex: 1;
        min-width: 100px;
        padding: 0.625rem 1rem;
        border-radius: 0.625rem;
        font-size: 0.875rem;
        font-weight: 600;
        border: none;
        cursor: pointer;
        transition: all 0.2s;
        text-align: center;
    }

        .edit-btn:hover {
            background: #d97706;
            transform: translateY(-1px);
        }

    .delete-btn {
        background: #ef4444;
        color: white;
        flex: 1;
        min-width: 100px;
        padding: 0.625rem 1rem;
        border-radius: 0.625rem;
        font-size: 0.875rem;
        font-weight: 600;
        border: none;
        cursor: pointer;
        transition: all 0.2s;
        text-align: center;
    }

        .delete-btn:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }

    .delete-modal {
        max-width: 500px;
    }

    .warning-text {
        color: #dc2626;
        font-weight: 600;
        margin-top: 1rem;
    }

    .btn-danger {
        background: #dc2626;
        color: white;
    }

        .btn-danger:hover {
            background: #b91c1c;
        }

    .btn-warning {
        background: #f59e0b;
        color: white;
    }

        .btn-warning:hover {
            background: #d97706;
        }

    .auth-required-message {
        color: #64748b;
        font-size: 0.875rem;
        padding: 0.75rem 1.5rem;
        background: #f1f5f9;
        border-radius: 0.75rem;
        border: 1px solid #e2e8f0;
    }

    .auth-message {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 1rem;
    }

    .login-btn {
        background: #3b82f6;
        color: white;
        padding: 0.75rem 1.5rem;
        border-radius: 0.75rem;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.2s;
    }

        .login-btn:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }

    @media (max-width: 768px) {
        .routine-actions {
            flex-direction: column;
        }

        .view-btn,
        .edit-btn,
        .delete-btn,
        .start-btn,
        .set-active-btn {
            width: 100%;
        }
    }

    .day-header h4 {
        font-size: 1rem;
        font-weight: 600;
        color: #1e293b;
        margin: 0;
    }

    .day-count {
        background: #3b82f6;
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    .exercises-list {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .rest-day {
        text-align: center;
        padding: 1.5rem;
        color: #94a3b8;
        font-style: italic;
        background: white;
        border-radius: 0.5rem;
        border: 1px dashed #e2e8f0;
    }

    @media (max-width: 768px) {
        .week-schedule {
            grid-template-columns: repeat(4, 1fr);
        }

        .routine-content {
            padding: 1rem;
        }

        .routine-description {
            font-size: 0.875rem;
        }

        .day-name {
            font-size: 0.625rem;
        }

        .day-exercises {
            width: 1.25rem;
            height: 1.25rem;
            font-size: 0.5rem;
        }
    }

    @media (max-width: 480px) {
        .week-schedule {
            grid-template-columns: repeat(3, 1fr);
        }

        .day-plan {
            padding: 1rem;
        }

        .day-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
        }

        .day-count {
            align-self: flex-start;
        }
    }

    /* Base Styles */
    .routines-page {
        padding: 2rem 1rem;
        background: #f8fafc;
        min-height: 100vh;
    }

    .routines-container {
        max-width: 1200px;
        margin: 0 auto;
    }

    .routines-content {
        background: white;
        border-radius: 1rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        padding: 2rem;
    }

    /* Header */
    .routines-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        padding-bottom: 1.5rem;
        border-bottom: 2px solid #e2e8f0;
    }

        .routines-header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: #1e293b;
            margin: 0;
        }

    .create-button {
        background: linear-gradient(135deg, #ea580c 0%, #c2410c 100%);
        color: white;
        padding: 0.75rem 1.5rem;
        border-radius: 0.75rem;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.3s;
        border: none;
        cursor: pointer;
    }

        .create-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(234, 88, 12, 0.3);
        }

    /* Active Routine Banner */
    .active-routine-banner {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        color: white;
        border-radius: 1rem;
        padding: 1.5rem;
        margin-bottom: 2rem;
    }

    .active-routine-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
    }

    .routine-info h3 {
        font-size: 1rem;
        font-weight: 600;
        margin-bottom: 0.5rem;
        opacity: 0.9;
    }

    .routine-info h4 {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 0.75rem;
    }

    .routine-details {
        display: flex;
        gap: 1rem;
        align-items: center;
        font-size: 0.875rem;
    }

    .public-tag {
        background: rgba(255, 255, 255, 0.2);
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
    }

    .remove-active-btn {
        background: rgba(255, 255, 255, 0.15);
        color: white;
        border: 1px solid rgba(255, 255, 255, 0.3);
        padding: 0.5rem 1.25rem;
        border-radius: 0.5rem;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
    }

        .remove-active-btn:hover {
            background: rgba(255, 255, 255, 0.25);
        }

    /* Grid */
    .routines-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 1.5rem;
    }

    /* Routine Cards */
    .routine-card {
        background: white;
        border: 2px solid #e2e8f0;
        border-radius: 1rem;
        padding: 1.5rem;
        transition: all 0.3s;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

        .routine-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
            border-color: #cbd5e1;
        }

    .active-routine {
        border-color: #3b82f6;
        background: linear-gradient(to bottom, #f0f9ff, white);
        position: relative;
    }

        .active-routine::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #3b82f6, #60a5fa);
            border-radius: 1rem 1rem 0 0;
        }

    .routine-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 1rem;
    }

    .routine-card h2 {
        font-size: 1.25rem;
        font-weight: 700;
        color: #1e293b;
        margin: 0;
        flex: 1;
    }

    .active-badge {
        background: #10b981;
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    .routine-description {
        color: #64748b;
        font-size: 0.9375rem;
        line-height: 1.6;
        margin: 0 0 1.25rem 0;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .routine-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
        padding-bottom: 1.25rem;
        border-bottom: 1px solid #f1f5f9;
    }

    .exercise-count {
        color: #64748b;
        font-size: 0.875rem;
        font-weight: 500;
    }

    .routine-meta .public-tag {
        background: #dcfce7;
        color: #166534;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    /* Buttons */
    .routine-actions {
        display: flex;
        gap: 0.75rem;
        flex-wrap: wrap;
    }

    .view-btn,
    .start-btn,
    .set-active-btn {
        flex: 1;
        min-width: 100px;
        padding: 0.625rem 1rem;
        border-radius: 0.625rem;
        font-size: 0.875rem;
        font-weight: 600;
        border: none;
        cursor: pointer;
        transition: all 0.2s;
        text-align: center;
    }

    .view-btn {
        background: #f8fafc;
        color: #475569;
        border: 2px solid #e2e8f0;
    }

        .view-btn:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
        }

    .start-btn {
        background: linear-gradient(135deg, #ea580c 0%, #c2410c 100%);
        color: white;
    }

        .start-btn:hover {
            background: linear-gradient(135deg, #c2410c 0%, #9a3412 100%);
            transform: translateY(-1px);
        }

    .set-active-btn {
        background: #3b82f6;
        color: white;
    }

        .set-active-btn:hover {
            background: #2563eb;
        }

        .set-active-btn.is-active {
            background: #10b981;
        }

    /* Empty State */
    .empty-state {
        grid-column: 1 / -1;
        text-align: center;
        padding: 4rem 2rem;
        color: #64748b;
    }

    .empty-icon {
        font-size: 4rem;
        margin-bottom: 1.5rem;
        opacity: 0.5;
    }

    .empty-state p {
        font-size: 1.125rem;
        margin-bottom: 1.5rem;
    }

    /* Modal */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        padding: 1rem;
        animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    .modal {
        background: white;
        border-radius: 1rem;
        width: 100%;
        max-width: 700px;
        max-height: 85vh;
        overflow-y: auto;
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
        animation: slideUp 0.3s ease;
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.5rem 2rem;
        border-bottom: 2px solid #f1f5f9;
    }

        .modal-header h2 {
            font-size: 1.75rem;
            font-weight: 700;
            color: #1e293b;
            margin: 0;
        }

    .modal-close {
        background: none;
        border: none;
        font-size: 1.75rem;
        color: #94a3b8;
        cursor: pointer;
        padding: 0.25rem;
        border-radius: 0.375rem;
        line-height: 1;
        transition: all 0.2s;
    }

        .modal-close:hover {
            color: #64748b;
            background: #f1f5f9;
        }

    .modal-body {
        padding: 2rem;
    }

    .modal-section {
        margin-bottom: 2rem;
    }

        .modal-section h3 {
            font-size: 1.125rem;
            font-weight: 600;
            color: #334155;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .modal-section p {
            color: #475569;
            line-height: 1.6;
            margin: 0;
        }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 1rem;
    }

    .info-item {
        display: flex;
        justify-content: space-between;
        padding: 0.75rem;
        background: #f8fafc;
        border-radius: 0.75rem;
        border: 1px solid #e2e8f0;
    }

    .info-label {
        color: #64748b;
        font-weight: 500;
    }

    .info-value {
        font-weight: 600;
        color: #1e293b;
    }

        .info-value.public {
            color: #166534;
            background: #dcfce7;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
        }

        .info-value.private {
            color: #475569;
            background: #f1f5f9;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
        }

        .info-value.active {
            color: #ea580c;
            background: #ffedd5;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
        }

    /* Exercises List */
    .exercises-list {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .exercise-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 0.75rem;
        padding: 1.25rem;
    }

    .exercise-header {
        display: flex;
        align-items: flex-start;
        gap: 1rem;
        margin-bottom: 1rem;
    }

    .exercise-number {
        width: 2rem;
        height: 2rem;
        background: #3b82f6;
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 0.875rem;
        flex-shrink: 0;
    }

    .exercise-title {
        flex: 1;
    }

        .exercise-title h4 {
            font-size: 1rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0 0 0.5rem 0;
        }

    .muscle-badge {
        background: #e2e8f0;
        color: #475569;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 500;
    }

    .exercise-specs {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
        gap: 0.75rem;
        margin-bottom: 1rem;
    }

    .spec-item {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem 0.75rem;
        background: white;
        border-radius: 0.5rem;
        border: 1px solid #e2e8f0;
    }

    .spec-label {
        color: #64748b;
        font-size: 0.875rem;
    }

    .spec-value {
        font-weight: 600;
        color: #1e293b;
        font-size: 0.875rem;
    }

    .exercise-notes {
        padding: 0.75rem;
        background: white;
        border-radius: 0.5rem;
        border: 1px solid #e2e8f0;
        font-size: 0.875rem;
    }

    .notes-label {
        display: block;
        color: #64748b;
        font-weight: 500;
        margin-bottom: 0.25rem;
        font-size: 0.75rem;
    }

    .exercise-notes p {
        color: #475569;
        margin: 0;
        line-height: 1.4;
    }

    .no-exercises {
        text-align: center;
        padding: 2rem;
        color: #94a3b8;
        background: #f8fafc;
        border-radius: 0.75rem;
        border: 2px dashed #e2e8f0;
        font-size: 0.9375rem;
    }

    /* Modal Footer */
    .modal-footer {
        padding: 1.5rem 2rem;
        border-top: 2px solid #f1f5f9;
        display: flex;
        gap: 0.75rem;
        flex-wrap: wrap;
    }

    .btn {
        flex: 1;
        min-width: 120px;
        padding: 0.75rem 1.5rem;
        border-radius: 0.75rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        text-align: center;
    }

    .btn-primary {
        background: linear-gradient(135deg, #ea580c 0%, #c2410c 100%);
        color: white;
    }

        .btn-primary:hover {
            background: linear-gradient(135deg, #c2410c 0%, #9a3412 100%);
            transform: translateY(-1px);
        }

    .btn-secondary {
        background: #3b82f6;
        color: white;
    }

        .btn-secondary:hover {
            background: #2563eb;
        }

    .btn-success {
        background: #10b981;
        color: white;
    }

    .btn-outline {
        background: transparent;
        color: #64748b;
        border: 2px solid #e2e8f0;
    }

        .btn-outline:hover {
            background: #f8fafc;
        }

    /* Scrollbar */
    .modal::-webkit-scrollbar {
        width: 6px;
    }

    .modal::-webkit-scrollbar-track {
        background: #f1f5f9;
    }

    .modal::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 3px;
    }

        .modal::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }

    /* Responsive */
    @media (max-width: 768px) {
        .routines-content {
            padding: 1.5rem;
        }

        .routines-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }

        .routines-grid {
            grid-template-columns: 1fr;
        }

        .active-routine-content {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }

        .routine-actions {
            flex-direction: column;
        }

        .view-btn,
        .start-btn,
        .set-active-btn {
            width: 100%;
        }

        .modal {
            margin: 0.5rem;
            max-height: 90vh;
        }

        .modal-header,
        .modal-body {
            padding: 1.25rem;
        }

        .info-grid {
            grid-template-columns: 1fr;
        }

        .exercise-specs {
            grid-template-columns: 1fr;
        }

        .modal-footer {
            flex-direction: column;
        }

        .btn {
            width: 100%;
        }
    }

    @media (max-width: 480px) {
        .routines-page {
            padding: 1rem 0.5rem;
        }

        .routines-content {
            padding: 1rem;
        }

        .routine-card {
            padding: 1.25rem;
        }
    }
</style>
